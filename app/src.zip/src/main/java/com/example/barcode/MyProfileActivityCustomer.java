package com.example.barcode;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.barcode.databinding.ActivityMyProfileCustomerBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MyProfileActivityCustomer extends AppCompatActivity {

    private TextView profileDetailsTextView,profileDetailsSurnameTextView;


    private ImageButton searchImageButton, orderImageButton, signOutImageButton;
    private Button WishlistButton;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mDatabaseReference;
    private FirebaseAuth mFirebaseAuth;
    private FirebaseUser firebaseUser;
    private ActivityMyProfileCustomerBinding binding;

    private String phoneNumber = SharedData.phoneNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMyProfileCustomerBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mFirebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = mFirebaseAuth.getCurrentUser();
        checkUserStatus();

        profileDetailsTextView = findViewById(R.id.profileDetails);
        profileDetailsSurnameTextView = findViewById(R.id.profileDetailsSurname);


        WishlistButton = findViewById(R.id.wishlistButton);
        orderImageButton = findViewById(R.id.orderImageButton);
        searchImageButton = findViewById(R.id.searchImageButton);
        signOutImageButton = findViewById(R.id.signOutImageButton);


        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mDatabaseReference = mFirebaseDatabase.getReference().child("userData").child("customer").child(phoneNumber);

        FirebaseAuth.AuthStateListener mAuthStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if(firebaseAuth.getCurrentUser() == null){
                    Intent intent = new Intent(MyProfileActivityCustomer.this, ChooseRole.class);
                    Toast.makeText(getApplicationContext(), "You have successfully signed out", Toast.LENGTH_LONG).show();
                    startActivity(intent);
                }
            }
        };


        mFirebaseAuth = FirebaseAuth.getInstance();
        mFirebaseAuth.addAuthStateListener(mAuthStateListener);

        mDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                AddProfileData profileData = snapshot.getValue(AddProfileData.class);
                profileDetailsTextView.setText("Name: " + profileData.getmName());
                profileDetailsSurnameTextView.setText("Surname: " + profileData.getmSurname());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        signOutImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mFirebaseAuth.signOut();
            }
        });

        WishlistButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyProfileActivityCustomer.this, WishListView.class);
                startActivity(intent);
            }
        });


        searchImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyProfileActivityCustomer.this, ProductFindCustomerActivity.class);
                startActivity(intent);
            }
        });

        orderImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyProfileActivityCustomer.this, WishListActivity.class);
                startActivity(intent);
            }
        });

    }

    private void checkUserStatus()
    {
        FirebaseUser firebaseUser = mFirebaseAuth.getCurrentUser();
        if(firebaseUser != null)
        {
            String phone = firebaseUser.getPhoneNumber();
            binding.phone.setText(phone);
        }
        else
        {
            finish();
        }
    }
}