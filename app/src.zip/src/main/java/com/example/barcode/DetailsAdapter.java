package com.example.barcode;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class DetailsAdapter extends RecyclerView.Adapter {

    List<WishListData> wishListDataList;

    public DetailsAdapter(List<WishListData> wishListDataList) {
        this.wishListDataList = wishListDataList;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.details_layout, parent, false);
        ViewHolderClass viewHolderClass = new ViewHolderClass(view);

        return viewHolderClass;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

        ViewHolderClass viewHolderClass = (ViewHolderClass) holder;

        WishListData wishListData = wishListDataList.get(position);
        viewHolderClass.productName.setText(wishListData.getmName());
        viewHolderClass.pieces.setText(wishListData.getmPieces() + "pcs.");
        viewHolderClass.price.setText("$" + wishListData.getmPrice());
    }

    @Override
    public int getItemCount() {
        return wishListDataList.size();
    }

    public class ViewHolderClass extends RecyclerView.ViewHolder{

        TextView productName, pieces, price;

        public ViewHolderClass(@NonNull View itemView) {
            super(itemView);
            productName = itemView.findViewById(R.id.productName);
            pieces = itemView.findViewById(R.id.pieces);
            price = itemView.findViewById(R.id.price);
        }
    }
}
