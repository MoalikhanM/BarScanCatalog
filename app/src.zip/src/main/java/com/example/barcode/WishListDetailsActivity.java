package com.example.barcode;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class WishListDetailsActivity extends AppCompatActivity {

    private TextView numberOfProductsTextView;
    private ImageButton backImageButton;
    private RecyclerView recyclerView;

    private int numberOfProducts = 0;

    List<WishListData> wishListDataList;
    com.example.barcode.DetailsAdapter detailsAdapter;

    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mDatabaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wishlist_details);

        numberOfProductsTextView = findViewById(R.id.numberOfProductsTextView);
        backImageButton = findViewById(R.id.backImageButton);
        recyclerView = findViewById(R.id.recyclerView);

        numberOfProductsTextView.setText(numberOfProducts + " products");

        backImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(WishListDetailsActivity.this, WishListView.class);
                startActivity(intent);
            }
        });

        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mDatabaseReference = mFirebaseDatabase.getReference("orderDetails").child(SharedData.getPhoneNumber());

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        DividerItemDecoration itemDecorator = new DividerItemDecoration(getApplicationContext(), DividerItemDecoration.VERTICAL);
        itemDecorator.setDrawable(ContextCompat.getDrawable(getApplicationContext(), R.drawable.item_layout));
        recyclerView.addItemDecoration(itemDecorator);

        wishListDataList = new ArrayList<>();

        detailsAdapter = new com.example.barcode.DetailsAdapter(wishListDataList);

        mDatabaseReference.child(SharedData.getDate()).child("products").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot dataSnapshot: snapshot.getChildren()){
                    WishListData wishListData = dataSnapshot.getValue(WishListData.class);
                    wishListDataList.add(wishListData);
                }
                detailsAdapter = new com.example.barcode.DetailsAdapter(wishListDataList);
                recyclerView.setAdapter(detailsAdapter);
                numberOfProducts = wishListDataList.size();
                if(numberOfProducts == 1){
                    numberOfProductsTextView.setText(numberOfProducts + " product");
                } else {
                    numberOfProductsTextView.setText(numberOfProducts + " products");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}