package com.example.barcode;

import androidx.appcompat.app.AppCompatDialogFragment;

public class EditProfileActivity extends AppCompatDialogFragment {

    /*private TextInputLayout Name, Surname, Store, City, Address, IIN, SIIN;

    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mDatabaseReference, mDatabaseReference1;

    private EditProductDialogListener listener;

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        LayoutInflater layoutInflater = getActivity().getLayoutInflater();
        View view = layoutInflater.inflate(R.layout.activity_edit_profile, null);

        builder.setView(view)
                .setTitle("Edit profile details")
                .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .setPositiveButton("Save changes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        mFirebaseDatabase = FirebaseDatabase.getInstance();
                        mDatabaseReference = mFirebaseDatabase.getReference("userData");
                        mDatabaseReference1 = mFirebaseDatabase.getReference("stores");

                        String mName = Name.getEditText().getText().toString();
                        String mSurname = Surname.getEditText().getText().toString();
                        String mStateID = IIN.getEditText().getText().toString();

                        String mStore = Store.getEditText().getText().toString();
                        String mCity = City.getEditText().getText().toString();
                        String mAddress = Address.getEditText().getText().toString();
                        String mINN = SIIN.getEditText().getText().toString();

                        AddProfileData profileData = new AddProfileData(mName, mSurname, mStateID);
                        AddStoreData addData = new AddStoreData(mINN, mStore, mCity,mAddress);

                        ProductData addData = new ProductData(mProductName, mBarcode, mPrice, mPieces);

                        mDatabaseReference.child(SharedData.getPhoneNumber()).child(SharedData.getBarcode()).setValue(addData);

                        Toast.makeText(getActivity(), "Data have been saved successfully!", Toast.LENGTH_SHORT).show();

                        listener.completeEdition();
                    }
                });

        Name = view.findViewById(R.id.FirstName);
        Surname = view.findViewById(R.id.SurName);
        IIN = view.findViewById(R.id.price);

        Store = view.findViewById(R.id.StoreName);
        City = view.findViewById(R.id.pieces);
        Address = view.findViewById(R.id.AddressName);
        SIIN = view.findViewById(R.id.pieces);

        Name.getEditText().setText(AddProfileData.getmName());
        Surname.getEditText().setText(AddProfileData.getmSurname());

        Store.getEditText().setText(AddStoreData.getmLegalName());
        City.getEditText().setText(AddStoreData.getPieces());
        Address.getEditText().setText(AddStoreData.getPieces());

        return builder.create();
    }

    public interface EditProductDialogListener{
        void completeEdition();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);

        try {
            listener = (EditProductDialogListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString() + "implement interface first");
        }
    }*/
}
