package com.example.barcode;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.vision.barcode.Barcode;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

public class ProductFindCustomerActivity extends AppCompatActivity {
    private TextView scanResult, productNameResult, priceResult, inStockResult, productDescriptionResult;
    private Button scanButton, wishlistButton, translateButton;
    private ImageButton myProfileImageButton, orderImageButton;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mDatabaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_find_customer);


        scanResult = findViewById(R.id.scanResult);
        productNameResult = findViewById(R.id.productNameResult);
        priceResult = findViewById(R.id.priceResult);
        inStockResult = findViewById(R.id.inStockResult);
        productDescriptionResult = findViewById(R.id.productDescriptionResult);


        wishlistButton = findViewById(R.id.wishlist);
        scanButton = findViewById(R.id.scanButton);
        translateButton = findViewById(R.id.translate);
        myProfileImageButton = findViewById(R.id.myProfileImageButton);
        orderImageButton = findViewById(R.id.orderImageButton);

        scanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProductFindCustomerActivity.this, ScanActivity.class);
                startActivityForResult(intent, 0);
            }
        });

        myProfileImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProductFindCustomerActivity.this, MyProfileActivityCustomer.class);
                startActivity(intent);
            }
        });

        orderImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProductFindCustomerActivity.this, MyProfileActivityCustomer.class);
                startActivity(intent);
            }
        });

        wishlistButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProductFindCustomerActivity.this, MyProfileActivityCustomer.class);
                startActivity(intent);
            }
        });

        TranslatorOptions options =
                new TranslatorOptions.Builder()
                        .setSourceLanguage(TranslateLanguage.ENGLISH)
                        .setTargetLanguage(TranslateLanguage.KOREAN)
                        .build();
        final Translator englishKoreanTranslator =
                Translation.getClient(options);

        DownloadConditions conditions = new DownloadConditions.Builder()
                .requireWifi()
                .build();
        englishKoreanTranslator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener(
                        new OnSuccessListener() {
                            @Override
                            public void onSuccess(Object o) {
                                //System.out.println("Sucessful Model download");
                            }
                        })
                .addOnFailureListener(
                        new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                //System.out.println("Failed to install model");
                            }
                        });

        translateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = productDescriptionResult.getText().toString();

                englishKoreanTranslator.translate(text)
                        .addOnSuccessListener(
                                new OnSuccessListener<String>() {
                                    @Override
                                    public void onSuccess(String s) {
                                        productDescriptionResult.setText(s);
                                    }
                                })
                        .addOnFailureListener(
                                new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        //System.out.println("Translation failed");
                                    }
                                });
            }
        });
    }

    public void readName(final String barcodeNumber) {
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mDatabaseReference = mFirebaseDatabase.getReference().child("products");

        mDatabaseReference.child(barcodeNumber).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ProductData productData = snapshot.getValue(ProductData.class);

                String mProductName = productData.getmProductName();
                productNameResult.setText(mProductName);

                String mPrice = productData.getmPrice();
                priceResult.setText(mPrice);

                String mInStock = productData.getmPieces();
                inStockResult.setText(mInStock);

                String mDescription = productData.getmDescription();
                productDescriptionResult.setText(mDescription);



                SharedData.setProductName(mProductName);
                SharedData.setBarcode(barcodeNumber);
                SharedData.setPrice(mPrice);
                SharedData.setPieces(mInStock);
                SharedData.setDescription(mDescription);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode == 0) {
            if(resultCode == CommonStatusCodes.SUCCESS) {
                if(data != null) {
                    Barcode barcode = data.getParcelableExtra("scannedCode");
                    String details = barcode.displayValue;
                    scanResult.setText(details);
                    readName(details);
                } else {
                    scanResult.setText("No code found");
                }
            }

        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
}