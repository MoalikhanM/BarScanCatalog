package com.example.barcode;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.barcode.databinding.ActivityMyProfileBinding;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MyProfileActivity extends AppCompatActivity {

    private TextView profileDetailsTextView,profileDetailsSurnameTextView, profileDetailsStoreTextView;
    private TextView profileDetailsCityTextView, profileDetailsAddressTextView;

    private ImageButton listImageButton, searchImageButton, addImageButton, orderImageButton, signOutImageButton;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mDatabaseReference, mDatabaseReference1;
    private FirebaseAuth mFirebaseAuth;
    private FirebaseUser firebaseUser;
    private ActivityMyProfileBinding binding;

    private String phoneNumber = SharedData.phoneNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMyProfileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        mFirebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = mFirebaseAuth.getCurrentUser();
        checkUserStatus();

        profileDetailsTextView = findViewById(R.id.profileDetails);
        profileDetailsSurnameTextView = findViewById(R.id.profileDetailsSurname);
        profileDetailsStoreTextView = findViewById(R.id.profileDetailsStore);
        profileDetailsCityTextView = findViewById(R.id.profileDetailsCity);
        profileDetailsAddressTextView = findViewById(R.id.profileDetailsAddress);


        listImageButton = findViewById(R.id.listImageButton);
        searchImageButton = findViewById(R.id.searchImageButton);
        addImageButton = findViewById(R.id.addImageButton);
        orderImageButton = findViewById(R.id.orderImageButton);
        signOutImageButton = findViewById(R.id.signOutImageButton);

        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mDatabaseReference = mFirebaseDatabase.getReference().child("userData").child(phoneNumber);

        mDatabaseReference1 = mFirebaseDatabase.getReference().child("stores").child(phoneNumber);

        FirebaseAuth.AuthStateListener mAuthStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if(firebaseAuth.getCurrentUser() == null){
                    Intent intent = new Intent(MyProfileActivity.this, ChooseRole.class);
                    Toast.makeText(getApplicationContext(), "You have successfully signed out", Toast.LENGTH_LONG).show();
                    startActivity(intent);
                }
            }
        };


        mFirebaseAuth = FirebaseAuth.getInstance();
        mFirebaseAuth.addAuthStateListener(mAuthStateListener);

        mDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                AddProfileData profileData = snapshot.getValue(AddProfileData.class);
                profileDetailsTextView.setText("Name: " + profileData.getmName());
                profileDetailsSurnameTextView.setText("Surname: " + profileData.getmSurname());

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        mDatabaseReference1.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                AddStoreData storeData = snapshot.getValue(AddStoreData.class);
                profileDetailsStoreTextView.setText("Store: " + storeData.getmLegalName());
                profileDetailsCityTextView.setText("City: " + storeData.getmCity());
                profileDetailsAddressTextView.setText("Address: " + storeData.getmAddress());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        signOutImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mFirebaseAuth.signOut();
            }
        });

        listImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyProfileActivity.this, ProductListActivity.class);
                startActivity(intent);
            }
        });

        searchImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyProfileActivity.this, ProductFindActivity.class);
                startActivity(intent);
            }
        });

        addImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyProfileActivity.this, AddProduct.class);
                startActivity(intent);
            }
        });

        orderImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MyProfileActivity.this, AddStoreTwo.class);
                startActivity(intent);
            }
        });
    }

    private void checkUserStatus()
    {
        FirebaseUser firebaseUser = mFirebaseAuth.getCurrentUser();
        if(firebaseUser != null)
        {
            String phone = firebaseUser.getPhoneNumber();
            binding.phone.setText(phone);
        }
        else
        {
            finish();
        }
    }
}