package com.example.barcode;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.common.api.CommonStatusCodes;
import com.google.android.gms.vision.barcode.Barcode;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class ProductFindActivity extends AppCompatActivity implements EditProductDialog.EditProductDialogListener, DeleteProductDialog.DeleteProductDialogListener{

    //private BottomNavigationView bottomNavigationView;
    private TextView scanResult, productNameResult, priceResult, inStockResult, productDescriptionResult;
    private Button scanButton;
    private ImageButton addImageButton, searchImageButton, myProfileImageButton, listImageButton, orderImageButton, editButton, deleteButton;
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mDatabaseReference;
    private String barcodeValue, productValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_find);

        //bottomNavigationView = findViewById(R.id.bottomNavigationView);

        scanResult = findViewById(R.id.scanResult);
        productNameResult = findViewById(R.id.productNameResult);
        priceResult = findViewById(R.id.priceResult);
        inStockResult = findViewById(R.id.inStockResult);
        productDescriptionResult = findViewById(R.id.productDescriptionResult);



        scanButton = findViewById(R.id.scanButton);
        addImageButton = findViewById(R.id.addImageButton);
        searchImageButton = findViewById(R.id.searchImageButton);
        myProfileImageButton = findViewById(R.id.myProfileImageButton);
        listImageButton = findViewById(R.id.listImageButton);
        orderImageButton = findViewById(R.id.orderImageButton);
        editButton = findViewById(R.id.editButton);
        deleteButton = findViewById(R.id.deleteButton);

        scanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProductFindActivity.this, ScanActivity.class);
                startActivityForResult(intent, 0);
            }
        });

        addImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProductFindActivity.this, AddProduct.class);
                startActivity(intent);
            }
        });

        myProfileImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProductFindActivity.this, MyProfileActivity.class);
                startActivity(intent);
            }
        });

        listImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProductFindActivity.this, ProductListActivity.class);
                startActivity(intent);
            }
        });

        orderImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProductFindActivity.this, AddStoreTwo.class);
                startActivity(intent);
            }
        });

        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog();
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                deleteDialog();
            }
        });

    }

    public void readName(final String barcodeNumber) {
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mDatabaseReference = mFirebaseDatabase.getReference().child("products");

        mDatabaseReference.child(SharedData.getPhoneNumber()).child(barcodeNumber).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ProductData productData = snapshot.getValue(ProductData.class);

                String mProductName = productData.getmProductName();
                productNameResult.setText(mProductName);

                String mPrice = productData.getmPrice();
                priceResult.setText(mPrice);

                String mInStock = productData.getmPieces();
                inStockResult.setText(mInStock);

                String mDescription = productData.getmDescription();
                productDescriptionResult.setText(mDescription);



                SharedData.setProductName(mProductName);
                SharedData.setBarcode(barcodeNumber);
                SharedData.setPrice(mPrice);
                SharedData.setPieces(mInStock);
                SharedData.setDescription(mDescription);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        editButton.setVisibility(View.VISIBLE);
        deleteButton.setVisibility(View.VISIBLE);
    }

    private void openDialog() {
        EditProductDialog editProductDialog = new EditProductDialog();
        editProductDialog.show(getSupportFragmentManager(), "Edit product details");
    }

    private void deleteDialog() {
        DeleteProductDialog deleteProductDialog = new DeleteProductDialog();
        deleteProductDialog.show(getSupportFragmentManager(), "Delete this product?");
    }

    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode == 0) {
            if(resultCode == CommonStatusCodes.SUCCESS) {
                if(data != null) {
                    Barcode barcode = data.getParcelableExtra("scannedCode");
                    String details = barcode.displayValue;
                    scanResult.setText(details);
                    readName(details);
                } else {
                    scanResult.setText("No code found");
                }
            }

        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void completeEdition() {
        editButton.setVisibility(View.INVISIBLE);
        deleteButton.setVisibility(View.INVISIBLE);
        scanResult.setText("");
        productNameResult.setText("");
        priceResult.setText("");
        inStockResult.setText("");
        productDescriptionResult.setText("");
    }

    @Override
    public void completeDelete() {
        editButton.setVisibility(View.INVISIBLE);
        deleteButton.setVisibility(View.INVISIBLE);
        scanResult.setText("");
        productNameResult.setText("");
        priceResult.setText("");
        inStockResult.setText("");
        productDescriptionResult.setText("");
    }
}