package com.example.barcode;

import android.content.Intent;
import android.os.Bundle;
import android.telephony.PhoneNumberFormattingTextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SignUpHolder extends AppCompatActivity{

    private EditText editTextPhoneNumber;
    private TextView textView;

    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mDatabaseReference;
    private ChildEventListener mChildEventListener;
    private FirebaseAuth mFirebaseAuth;
    private FirebaseAuth.AuthStateListener mAuthStateListener;

    private String phoneNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_holder);

        textView = findViewById(R.id.textView);
        editTextPhoneNumber = findViewById(R.id.editTextPhone);

        editTextPhoneNumber.addTextChangedListener(new PhoneNumberFormattingTextWatcher());

        //mFirebaseAuth = FirebaseAuth.getInstance();

        findViewById(R.id.nextButton).setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {

                phoneNumber = editTextPhoneNumber.getText().toString();

                mFirebaseDatabase = FirebaseDatabase.getInstance();
                mDatabaseReference = mFirebaseDatabase.getReference().child("users").child(phoneNumber);

                mDatabaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.exists() && phoneNumber.length() > 0) {
                            editTextPhoneNumber.setError("This phone number is already registered.");
                            editTextPhoneNumber.requestFocus();
                            return;
                        } else if(isValid(phoneNumber) == true){
                            Intent intent = new Intent(SignUpHolder.this, VerifyPhoneActivity.class);
                            intent.putExtra("phoneNumber", phoneNumber);
                            startActivity(intent);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }
        });

    }

    private boolean isValid(String phoneNumber){
        if(phoneNumber.isEmpty() || phoneNumber.length() < 12){
            editTextPhoneNumber.setError("Invalid phone number");
            return false;
        } else {
            return true;
        }
    }

    /*protected void onStart() {
        super.onStart();

        if (mFirebaseAuth.getCurrentUser() != null) {
            Intent intent = new Intent(this, ProfileActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

            startActivity(intent);
        }
    }*/

    /*ublic void sendPhoneNumber(View view) {
        String phoneNumber = editTextPhoneNumber.getText().toString();

        if(phoneNumber.isEmpty() || phoneNumber.length() < 10){
            editTextPhoneNumber.setError("Invalid phone number");
            editTextPhoneNumber.requestFocus();
            return;
        }

        Intent intent = new Intent(MainActivity.this, VerifyPhoneActivity.class);
        intent.putExtra("phoneNumber", phoneNumber);
        startActivity(intent);
    }*/
}